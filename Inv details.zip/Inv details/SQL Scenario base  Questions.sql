==================================Scenario based Sql Questions=============================================================
********************************Question1**************************************************************
create table student (studentid int,subject varchar(300),marks int)

insert into student values (1001,'English',88),(1001,'Science',90),(1001,'Maths',85),
(1002,'English',70),(1002,'Science',80),(1002,'Maths',83)

Expected Output:
|studentid|	English|Science	 |Maths
|1001	  |    88  |90	     |  85
|1002	  |    70  |80       | 83

Write a Query to Transpose the student data

select studentid, Sum(Case when Subject='English' THEN marks else 0 end) AS English,
sum(Case when Subject='Science' THEN marks else 0 end)as Science,
sum(Case when Subject='Maths' THEN marks else 0 end) as Maths
from student
group by studentid

*********************************Question2****************************************************************

Create table customer(salesdate date default getdate(),customerid varchar(30),Amount int,Payment_mode varchar(30))

Insert into customer(customerid,Amount,Payment_mode) values ('cust1',150,'Cash'),('cust1',500,'Online'),('cust2',450,'Online'),('cust1',100,'Cash'),('cust3',600,'Cash'),('cust5',200,'Online'),('cust2',100,'Online')

Write a Query to find the totalamount paid by each customer cash and online

Expected Output:
customerid	Cash	Online
cust1	   250	    500
cust2	   0	    550
cust3	   600	     0
cust5	   0	    200

Select customerid
,Sum(Case when payment_mode='Cash' then Amount else 0 end )As Cash
,sum(Case when Payment_mode ='Online' then Amount else 0 end )As Online
from customer 
group by customerid

***********************************Question 3************************************************************************
Create table numbers(A int,B int)
insert into numbers values (1,2),(2,1),(2,3),(3,2),(4,5),(5,6),(6,5),(7,8)

Write a Query to remove the reverse pair numbers 

Expected Output:
A	B
1	2
2	3
4	5
5	6
7	8

**Method 1**:Using Join Condition
---------------------------------
select N1.A,N1.B from numbers as N1 Left join numbers as N2 on N1.B=N2.A AND N1.A=N2.B where N2.a is null or N1.A<N2.A

***Method 2**:Using Exist or Not Exist
-------------------------------------
select * from numbers as N1 where not exists(select *from numbers as N2 where N1.B=N2.A and N2.B=N1.A and N1.A>N2.A)

***********************************Question4************************************************************************
create table joins(A varchar(10))
insert into joins values (1),(2),(3),(Null)

create table joins1(B varchar(10))
insert into joins1 values(Null) (2),(3),(Null)

Expected Output:

A	     B
2	     2
3	     3
NULL	NULL
NULL	NULL

write a query to generate the output including the null values using joins

select * from joins as J1 join Joins1 as J2 on J1.A=j2.B or J1.A IS NULL AND J2.B IS NULL

*****************************************Question 5***********************************************************
                                  6
								/  \
							  5      4
							 / \        \
						    3	2		  1

Write a Query to print the each node and thier parent

create table nodes(N varchar(10),P varchar(10))
insert into nodes values (5,6),(4,6),(6,NULL),(3,5),(2,5),(1,4)

Query:

select N as Node,Case when p is null then 'Root' 
when N not in(select distinct (P) from nodes where p is not null) then 'Branch'
else 'Leaf' end from nodes

***********************************Question 6************************************************************************

Create table transactions(Custid int,transactid int,transfer_amount int,Transfer_Date datetime)
insert into transactions values(1001,20001,10000,2020-04-25),(1001,20002,15000,2020-04-25),(1001,20003,80000,2020-04-25),
(1001,20004,20000,2020-04-25),(1002,30001,7000,2020-04-25),(1002,30002,15000,2020-04-25),(1002,30003,000,2020-04-25)

Write a Query Display Maximum transfer amount for each customer and ratio of transfer amount and maximum amount for each transaction 

;with cte as (Select custid,transactid,cast(Max(transfer_amount) as Decimal(10,5)) Transfer_amount from transactions 
group by custid,transactid),cte1 as (select custid,cast(max(transfer_amount)  as Decimal(10,5)) max_amount from transactions group by custid)
select c.custid,c.transactid,c.Transfer_amount,c1.max_amount,cast(c.Transfer_amount/c1.max_amount as decimal(10,5)) from cte as c join cte1 as c1 on c.custid=c1.custid


************************************Question 7****************************************************************************
create table Training(id int,traningname varchar(30),classroom varchar(30),starttime datetime,duration decimal(4,2),Wk varchar(20))

insert into Training values (1,'SQl server','silver Room',getdate(),2.00,'M')
insert into Training values (2,'SQl server','silver Room',getdate(),2.00,'T')
insert into Training values (3,'SQl server','silver Room',getdate(),2.00,'W')
insert into Training values (4,'SQl server','silver Room',getdate(),2.00,'F')
insert into Training values (5,'MSBI','Gold Room',getdate(),1.45,'M')
insert into Training values (6,'MSBI','Gold Room',getdate(),1.45,'T')
insert into Training values (7,'MSBI','Gold Room',getdate(),1.45,'F')


select distinct traningname,classroom,duration,(
select stuff((SELECT ','+WK 
FROM Training as a where a.traningname=b.traningname for xml path('')),1,1,'')) from Training as b



****************************************Question8*************************************************************************************

-->> PROBLEM STATEMENT: Ungroup the given input data. Display the result as per expected output.

-- Dataset:
drop table travel_items;
create table travel_items
(
id              int,
item_name       varchar(50),
total_count     int
);
insert into travel_items values
(1, 'Water Bottle', 2),
(2, 'Tent', 1),
(3, 'Apple', 4);


-->> EXPECTED OUTPUT:
ID    ITEM_NAME
1	  Water Bottle
1	  Water Bottle
2	  Tent
3	  Apple
3	  Apple
3	  Apple
3	  Apple


-->> SOLUTION:
SQL Server:
;with  cte as
    (select id, item_name, total_count, 1 as level
    from travel_items
    union all
    select cte.id, cte.item_name, cte.total_count - 1, level+1 as level
    from cte
    join travel_items t on t.item_name = cte.item_name and t.id = cte.id
    where cte.total_count > 1
    )
select id, item_name
from cte
order by 1;

****************************************************************Question 9*****************************************************************************************
create table test# (Id int )
create table test1# (id int )

Insert into test# values (1),(3),(5),(7),(9)
insert into test1# values (2),(4),(6),(8),(10)

select distinct isnull(a.id,b.id) from test# as a Full outer Join test1# as b on a.id=b.id 

*****************************************************************Question10*****************************************************************************************
-- Dataset
drop table emp_input;
create table emp_input
(
id      int,
name    varchar(40)
);
insert into emp_input values (1, 'Emp1');
insert into emp_input values (2, 'Emp2');
insert into emp_input values (3, 'Emp3');
insert into emp_input values (4, 'Emp4');
insert into emp_input values (5, 'Emp5');
insert into emp_input values (6, 'Emp6');
insert into emp_input values (7, 'Emp7');
insert into emp_input values (8, 'Emp8');

select * from emp_input;



-- Solution in PostgreSQL & Microsoft SQL Server:
with cte as
    (select concat(id, ' ', name) as name
    , ntile(4) over(order by id) as buckets
    from emp_input)
select string_agg(name, ', ') as final_result
from cte
group by buckets
order by 1


-- Solution in MySQL:
with cte as
    (select concat(id, ' ', name) as name
    , ntile(4) over(order by id) as buckets
    from emp_input)
select group_concat(name) as final_result
from cte
group by buckets
order by 1


-- Solution in Oracle:
with cte as
    (select concat(id, ' ', name) as name
    , ntile(4) over(order by id) as buckets
    from emp_input)
select listagg(name, ', ') as final_result
from cte
group by buckets
order by 1

***********************************************************Question11**************************************************************
Write a SQL Query to find Student details who scored marks greater than equal to previous year

CREATE TABLE STUDENT_MARKS(
   STUDENT_NAME VARCHAR(50),
   TOTAL_MARKS NUMBER,
   YEAR NUMBER(4)
);

INSERT INTO STUDENT_MARKS VALUES('Ram','90','2010');
INSERT INTO STUDENT_MARKS VALUES('Neena','80','2010');
INSERT INTO STUDENT_MARKS VALUES('John','70','2010');
INSERT INTO STUDENT_MARKS VALUES('Ram','90','2011');
INSERT INTO STUDENT_MARKS VALUES('Neena','85','2011');
INSERT INTO STUDENT_MARKS VALUES('John','65','2011');
INSERT INTO STUDENT_MARKS VALUES('Ram','80','2012');
INSERT INTO STUDENT_MARKS VALUES('Neena','80','2012');
INSERT INTO STUDENT_MARKS VALUES('John','90','2012');

Sol:
;With cte as (
select
lead(total_marks)over(partition by student_name order by year desc) as Previous_year,* from Student_marks)
select student_name,total_marks,Previous_year,year from cte
where total_marks >=Previous_year
**************************************************************Question12************************************************
CREATE TABLE BALANCES(
   BALANCE int,
   DATES DATE
);

INSERT INTO BALANCES VALUES('26000','2020-01-01');
INSERT INTO BALANCES VALUES('26000','2020-01-02');
INSERT INTO BALANCES VALUES('26000','2020-01-03');
INSERT INTO BALANCES VALUES('30000','2020-01-04');
INSERT INTO BALANCES VALUES('30000','2020-01-05');
INSERT INTO BALANCES VALUES('26000','2020-01-06');
INSERT INTO BALANCES VALUES('26000','2020-01-07');
INSERT INTO BALANCES VALUES('32000','2020-01-08');
INSERT INTO BALANCES VALUES('31000','2020-01-09');

Write a SQL Query to find Start_date and End_date when there is a constant Balance amount for continuous Dates.

;With cte as (
select BALANCE,dates,
Row_number() over(order by dates asc) as date_rank,
Row_number()over(partition by balance order by dates) as balance_rank,
Row_number() over(order by dates)  -
Row_number()over(partition by balance order by dates)  as diff 
from BALANCES )
select balance,min(dates) as start_date,max(dates) as end_date from cte 
group by balance,diff 

*******************************************************Question13************************************************
Write a Query to identify missing Sequence numbers from table?
CREATE TABLE NUMBERS(
   ID int);

INSERT INTO NUMBERS VALUES(1);
INSERT INTO NUMBERS VALUES(4);
INSERT INTO NUMBERS VALUES(7);
INSERT INTO NUMBERS VALUES(9);
INSERT INTO NUMBERS VALUES(12);
INSERT INTO NUMBERS VALUES(14);
INSERT INTO NUMBERS VALUES(16);
INSERT INTO NUMBERS VALUES(17);
INSERT INTO NUMBERS VALUES(20);


;with cte(id) as (
select min(id) as id from numbers
union all
select id+1 as id from cte where id <(select max(id)as id from numbers)
select id from cte 

******************************************************************************************
CREATE TABLE TEAMS(
   COUNTRY VARCHAR(50)
);

INSERT INTO TEAMS VALUES('India');
INSERT INTO TEAMS VALUES('Srilanka');
INSERT INTO TEAMS VALUES('Bangladesh');
INSERT INTO TEAMS VALUES('Pakistan');

select * from teams

;with cte as 
(select 1 as dummy,
case when country='India' then 1
 when country='Srilanka' then 2 
 when country='Bangladesh' then 3
 when country='Pakistan' then 4 end as id,COUNTRY from TEAMS)
select c.country as 'team-A' ,c1.country as 'team-b' from cte as c join cte as c1 on c.dummy=c1.dummy and
c.id < c1.id
***********************************************************Question 15*******************************
Write a Query to Convert Column data into Rows data ?

Create table Travels (Name varchar(30),City varchar(30))

name	City
Sachin	Mumbai
Virat	Delhi
Rahul	Banglore
Rohit	Mumbai
Mayank	Banglore

Select Rno,
Max(Case when City='Banglore' then  Name end) as Banglore
,max(Case when City='Mumbai' then  Name end) as Mumbai
,max(Case when City='Delhi' then  Name end) as Delhi
from (
select *,ROW_NUMBER() over (Partition by City order by Name asc) as Rno from Travels)
a
group by Rno
***********************************************************Question 16*******************************
Write a Query identify Candidate login and logoff intervals?

create table event_status
(
event_time varchar(10),
status varchar(10)
);
insert into event_status 
values
('10:01','on'),('10:02','on'),('10:03','on'),('10:04','off'),('10:07','on'),('10:08','on'),('10:09','off')
,('10:11','on'),('10:12','off');

;with cte as (
select *,
Sum(Case when status='on' and prev='off' then 1 else 0 END ) over(order by event_time) AS Groupkey
from (
select *,Lag(status,1,status) over (order  by event_time) as Prev from event_status) a )
select Min(Event_time) as login_time,Max(event_time) as Logoff_time,Count(1)-1 as intervals from cte 
group by  Groupkey


**************************************************Question 17 **************************************************
Create table Jounery (Custid int,Flight_id varchar(30),Origin varchar(30),Destination varchar(30))

insert into Jounery values (1,'Flight1','Delhi','Hyderabad')
insert into Jounery values (1,'Flight3','Hyderabad','Manglore')
insert into Jounery values (2,'Flight1','Mumbai','Ayodhya')
insert into Jounery values (2,'Flight2','Ayodhya','Gorakhpur')

Write q Query display the Customer Origin City and destination?

;with cte as (select custid,Origin from jounery where Origin not in (select destination from jounery))
,Cte1 as (Select custid,destination from jounery where destination not in (select origin from jounery))
select t1.custid,t1.origin,t2.destination from cte as t1 join cte1 as t2 on t1.custid=t2.custid

*************************************************Question 18*********************************************************
CREATE TABLE sales 
(
    order_date date,
    customer VARCHAR(512),
    qty INT
);

INSERT INTO sales (order_date, customer, qty) VALUES ('2021-01-01', 'C1', '20');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-01-01', 'C2', '30');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-02-01', 'C1', '10');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-02-01', 'C3', '15');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-03-01', 'C5', '19');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-03-01', 'C4', '10');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-04-01', 'C3', '13');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-04-01', 'C5', '15');
INSERT INTO sales (order_date, customer, qty) VALUES ('2021-04-01', 'C6', '10');

Write a Query to find the New Customer are added in Each month?
;with cte as (
select *,ROW_NUMBER() over(Partition by Customer order by order_date) as rno from sales)
select Order_Date,Count(customer) as Count_of_customer from cte where rno=1
group by order_date

*********************************************Question 19 *******************************************************************
drop table if exists customer_data 

Create table customer_data (custid varchar(10),Origin varchar(30),destination varchar(30))

 insert into customer_data values ('c1', 'New York', 'Lima')
   insert into customer_data values  ('c1', 'London', 'New York')
   insert into customer_data values  ('c1', 'Lima', 'Sao Paulo')
    insert into customer_data values ('c1', 'Sao Paulo', 'New Delhi')
   insert into customer_data values  ('c2', 'Mumbai', 'Hyderabad')
    insert into customer_data values ('c2', 'Surat', 'Pune')
     insert into customer_data values('c2', 'Hyderabad', 'Surat')
   insert into customer_data values  ('c3', 'Kochi', 'Kurnool')
    insert into customer_data values ('c3', 'Lucknow', 'Agra')
    insert into customer_data values ('c3', 'Agra', 'Jaipur')
    insert into customer_data values ('c3', 'Jaipur', 'Kochi')

Write a Query to find the Customer starting and ending Point?

with t1 AS (select custid,origin  from customer_data where origin not in (select destination from customer_data))
,t2 AS (select custid,destination from customer_data where destination not in (select Origin from customer_data))
select t1.custid,t1.Origin,t2.destination from t2 join t1 on t2.custid=t1.custid


*******************************************Question 20************************************************************************
Create table Salary (Name varchar(30),Deptid int,Salary int)

Insert into salary values ('Siva',1,30000)
Insert into salary values   ('Ravi',2,40000)
Insert into salary values  ('Prasad',1,50000)
Insert into salary values ('Arun',1,30000)
Insert into salary values  ('Sai',2,20000)


  Output:
  Arun     Prasad
  sai	   Ravi

Write a Query to display mininum salary and max slary Employee name

;with cte as (
select * from salary where salary in (select max(salary) from salary group by deptid ))
,Cte1 as (select * from salary where salary in (select  min(salary) from salary group by deptid ))
,cte2  as (select *,Row_number()over(Partition by salary order by name asc) as rno from cte1)
select c.name,c1.name from cte2 as c join cte as c1 on c1.deptid=c.deptid
where c.rno=1
order by c.name asc
*******************************************Question 21************************************************************************
Create table  Enrollments 
(student_id int, 
course_id int, 
grade int
);

insert into Enrollments (student_id, course_id, grade) values ('2', '2', '95') ,
('2', '3', '95'),
('1', '1', '90'),
('1', '2', '99'),
('3', '1', '80'),
('3', '2', '75'),
('3', '3', '82');

Write a Query to find the highest grade corresponding Course for each student,in case of tie you find the smallest Courseid and sorting the data based on studentid

;with cte as (select *,ROW_NUMBER() over(Partition by student_id order  by grade desc) rno  
from enrollments)
select student_id,Course_id,grade from cte where rno=1
order by student_id

**********************************************Question 22************************************************************************
Create table  Employee (
Id int, 
Name varchar(255), 
Department varchar(255), 
ManagerId int
);

insert into Employee(Id, Name, Department, ManagerId) values 
('101', 'John', 'A', Null),
('102', 'Dan', 'A', '101'), 
('103', 'James', 'A', '101'), 
('104', 'Amy', 'A', '101'),
('105', 'Anne', 'A', '101'),
('106', 'Ron', 'B', '101'),
('107', 'Tony', 'C', '103'),
('108', 'Rocky', 'C', '103');

Write Query that find out manager with at least 5 Direct Reportees?

select name from (select e.name ,Count(*) as total_Count from Employee as e
join Employee as m 
on e.Id=m.ManagerId
Group by E.name)
a where total_Count>=5

****************************************Question 23**********************************************************************************
Create table Failed 
(
 fail_date date
);

Create table  Succeeded 
(
 success_date date
);

insert into Failed (fail_date) 
values ('2018-12-28')
,('2018-12-29')
,('2019-01-04')
,('2019-01-05');

insert into Succeeded (success_date) values ('2018-12-30'),
('2018-12-31'),
('2019-01-01'),
('2019-01-02'),
 ('2019-01-03'),
 ('2019-01-06');

Write a Query to generate a report of period_state from each continous interval of days in 2019-01-01 to 2019-12-31?

;with cte as (
select 'Failed' as Period_State,fail_date AS Event_Date from failed  where fail_date between '2019-01-01' and '2019-12-31'
Union all
select 'succeeded' as Period_State,success_date AS Event_Date from Succeeded  where success_date between '2019-01-01' and '2019-12-31')
,cte1 as (select *,lag(Period_State,1,Period_State) over(Order  by event_date) as Previous_State from cte)
,cte2 as (select *,
Sum(Case when Period_State=Previous_State then 0 else 1 end) over(Order by event_date) as flag     from cte1)
select Period_State,Min(event_date) as startdate,Max(event_date) as Enddate
 from cte2
group by Period_State,flag


**************************************************Question 24********************************************************************
CREATE TABLE [dbo].[Userslogin](
	[userid] [int] NULL,
	[logindate] [datetime] NULL

Insert into Userslogin values(1, '2024-03-01')
Insert into Userslogin values(1, '2024-03-02')
Insert into Userslogin values(1, '2024-03-03')
Insert into Userslogin values(1, '2024-03-04')
Insert into Userslogin values(1, '2024-03-06')
Insert into Userslogin values(1, '2024-03-10')
Insert into Userslogin values(1, '2024-03-11')
Insert into Userslogin values(1, '2024-03-12')
Insert into Userslogin values(1, '2024-03-13')
Insert into Userslogin values(1, '2024-03-14')
Insert into Userslogin values(1, '2024-03-20')
Insert into Userslogin values(1, '2024-03-25')
Insert into Userslogin values(1, '2024-03-26')
Insert into Userslogin values(1, '2024-03-27')
Insert into Userslogin values(1, '2024-03-28')
Insert into Userslogin values(1, '2024-03-29')
Insert into Userslogin values(1, '2024-03-30')
Insert into Userslogin values(2, '2024-03-01')
Insert into Userslogin values(2, '2024-03-02')
Insert into Userslogin values(2, '2024-03-03')
Insert into Userslogin values(2, '2024-03-04')
Insert into Userslogin values(3, '2024-03-01')
Insert into Userslogin values(3, '2024-03-02')
Insert into Userslogin values(3, '2024-03-03')
Insert into Userslogin values(3, '2024-03-04')
Insert into Userslogin values(3, '2024-03-04')
Insert into Userslogin values(3, '2024-03-04')
Insert into Userslogin values(3, '2024-03-05')
Insert into Userslogin values(4, '2024-03-01')
Insert into Userslogin values(4, '2024-03-02')
Insert into Userslogin values(4, '2024-03-03')
Insert into Userslogin values(4, '2024-03-04')
Insert into Userslogin values(4, '2024-03-04')

Write a Query to find the userid login more than 5 consecutive days return the userid,startdate,enddate,no of consective days .if user login is spanning more than 5 days those user's needs to exculded?

;with cte as (
select *,Logindate -DENSE_RANK() over(Partition by Userid order  by Logindate) as diff from userslogin)
,cte1 as (select userid,Min(Logindate) as startdate,Max(Logindate) as enddate ,diff,Datediff(dd,min(Logindate),Max(Logindate)+1) 
daysCount  from cte
Group by diff,userid)
select userid,startdate,enddate,daysCount from cte1
Where daysCount>=5
************************************************************Question 25*****************************************************************************
Create table Student_1 (Studentid varchar(3),Studentname varchar(30),Marks int)

insert into student_1 values ('A','X',80)
insert into student_1 values ('A','Y',70)
insert into student_1 values ('A','Z',75)
insert into student_1 values ('B','X',90)
insert into student_1 values ('B','Y',91)
insert into student_1 values ('B','Z',75)
insert into student_1 values ('C','X',60)
insert into student_1 values ('C','Y',93)
insert into student_1 values ('C','Z',81)

Output:
 Studentid  Marks
  B	    181
  c         174

Write a Query to display the students whose total of two highest marks that are atleast 160 ?

;with cte as (
select *,ROW_NUMBER()over(Partition by studentid order  by Marks desc)Rno from Student_1)
select Studentid,Sum(Marks) as Total_marks from cte where rno <=2
group by studentid
having sum(marks)>=160

*********************************************************Question 26 **********************************************************************************
Create table Lift (id int,Weight int)
insert into lift values (1,300)
insert into lift values   (2,350)


Create table Passengers(Passenger_Name varchar(30), Weight int, liftid int)

insert into Passengers values ('Rahul',85,1)
insert into Passengers values ('adrsh',73,1)
insert into Passengers values ('Riti',95,1)
insert into Passengers values ('viraj',80,1)
insert into Passengers values ('vimal',83,2)
insert into Passengers values ('neha',77,2)
insert into Passengers values ('Priti',73,2)
insert into Passengers values ('Himanshi',85,2)

Output:
liftid	Pass_Name
1	adrsh,Rahul,viraj
2	Himanshi,neha,Priti,vimal

;with cte as (select *,Sum(Weight) over (Partition by liftid  order by weight asc Rows between unbounded preceding and Current Row) as Sumweigh from 
Passengers)
,Cte1 as (select Passenger_Name,SumWeigh,Liftid from cte)
,Cte2 as (select distinct c.Passenger_Name,c.SumWeigh,c.Liftid from cte1 as c join cte as c1 
on c.liftid=c1.Liftid )
,cte3 as  (select *,case when sumweigh <= Weight then  c1.Passenger_Name end as Name
from Cte2 as c1 join Lift as l on c1.liftid=l.id)
select liftid,STRING_AGG(Name,',') as Pass_Name from cte3
Group by liftid
order  by liftid

************************************************************Question 27 ****************************************************
Create table Fb_Friends( User1 int,User2 int)

Insert into Fb_Friends values (1,5)
Insert into Fb_Friends values (1,3)
Insert into Fb_Friends values  (1,6)
Insert into Fb_Friends values  (2,1)
Insert into Fb_Friends values  (2,6)
Insert into Fb_Friends values (3,9)
Insert into Fb_Friends values (4,1)
Insert into Fb_Friends values (7,2)
Insert into Fb_Friends values (8,3)

Output :
user1	Percentage
1	55.55555555500
2	33.33333333300
3	33.33333333300
4	11.11111111100
5	11.11111111100
6	22.22222222200
7	11.11111111100
8	11.11111111100
9	11.11111111100

Write a Query to find the Popularity percentage  for each user ?output each user along with their popularity percentage order Records based on userid?

;with cte as (select user1 from Fb_Friends
Union all
select user2 from fb_friends)
,cte1 as (select distinct user1,Count(*) as Usercount from cte 
group by  user1 
)
select user1,UserCount,Cast(UserCount as Decimal)/(select Count(*) from cte1)*100 as Percentage  from cte1

***********************************************************Question 28****************************************************************************************
Create table Product_sales (Product varchar(3),Region varchar(30),Sales int)

Insert into Product_sales values ('A','North',2000)
Insert into Product_sales values ('A','South',3000)
Insert into Product_sales values ('A','East',2400)
Insert into Product_sales values ('B','North',5000)
Insert into Product_sales values ('B','South',1000)
Insert into Product_sales values ('B','East',6000)
Insert into Product_sales values ('C','North',2500)
Insert into Product_sales values ('C','South',300)
Insert into Product_sales values ('C','East',4800)
Insert into Product_sales values ('D','North',1500)
Insert into Product_sales values ('D','South',2480)
Insert into Product_sales values ('D','East',2680)

Output:
Product	North	South	East
A	2000	3000	2400
B	5000	1000	6000
C	2500	300	4800
D	1500	2480	2680

Write a Query to Convert rows into Columns ?

select Product,
Sum(Case when Region='North' then Sales end ) as North
,Sum(case when Region='South' then sales end) as South
,Sum(case when Region='East' then sales end )as East
from Product_sales
Group by Product

==========================================================***Question 29 ****===================================================================
-- Create the 'products' table
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(255)
);

-- Create the 'cities' table
CREATE TABLE cities (
    city_id INT PRIMARY KEY,
    city_name VARCHAR(255)
);

-- Create the 'sales' table
CREATE TABLE sales (
    sale_id INT PRIMARY KEY,
    product_id INT,
    city_id INT,
    FOREIGN KEY (product_id) REFERENCES products(product_id),
    FOREIGN KEY (city_id) REFERENCES cities(city_id)
);

-- Insert data into the 'products' table
INSERT INTO products (product_id, product_name)
VALUES
    (1, 'Product A'),
    (2, 'Product B'),
    (3, 'Product C'),
    (4, 'Product D');

-- Insert data into the 'cities' table
INSERT INTO cities (city_id, city_name)
VALUES
    (1, 'City X'),
    (2, 'City Y'),
    (3, 'City Z');

-- Insert data into the 'sales' table
INSERT INTO sales (sale_id, product_id, city_id)
VALUES
    (1, 1, 1),  -- Product A sold in City X
    (2, 1, 2),  -- Product A sold in City Y
    (3, 2, 2),  -- Product B sold in City Y
    (4, 2, 3),  -- Product B sold in City Z
    (5, 3, 1),  -- Product C sold in City X
    (6, 3, 2),  -- Product C sold in City Y
    (7, 4, 1),  -- Product D sold in City X
    (8, 4, 2);  -- Product D sold in City Y

Write a Query to List the products that have been sold in all cities where the company operates?


select p.Product_name,p.product_id from [dbo].[products] as P 
Inner join [dbo].[sales] as s on p.product_id=s.product_id 
inner join [dbo].[cities] as c on s.city_id=c.city_id 
group by p.Product_name,p.product_id
having Count(distinct (s.city_id))=(select count(*) from cities)


======================================================***Question 30 ************=========================================================
-- Create the 'purchases' table
CREATE TABLE purchases (
    purchase_id INT PRIMARY KEY,
    customer_id INT,
    purchase_amount DECIMAL(10, 2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
-- Create the 'customers' table
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(255)
);


-- Insert sample data into 'customers' table
INSERT INTO customers (customer_id, customer_name)
VALUES
    (101, 'Alice'),
    (102, 'Bob'),
    (103, 'Charlie'),
    (104, 'David'),
    (105, 'Eve');

-- Insert sample data into 'purchases' table
INSERT INTO purchases (purchase_id, customer_id, purchase_amount)
VALUES
    (1, 101, 500.00),    -- Alice made a purchase of 500.00
    (2, 102, 1500.00),   -- Bob made a purchase of 1500.00
    (3, 103, 2000.00),   -- Charlie made a purchase of 2000.00
    (4, 101, 300.00),    -- Alice made a purchase of 300.00
    (5, 104, 1200.00),   -- David made a purchase of 1200.00
    (6, 102, 2500.00),   -- Bob made a purchase of 2500.00
    (7, 105, 2200.00),   -- Eve made a purchase of 2200.00
    (8, 103, 1800.00),   -- Charlie made a purchase of 1800.00
    (9, 104, 1400.00),   -- David made a purchase of 1400.00
    (10, 105, 3500.00);  -- Eve made a purchase of 3500.00














========================================
*********************************delete duplicate values from table *****************************************************8
Create  proc delete_dup (@Table_name varchar(max))
as 
begin
declare @Columnlist varchar(Max)
Select @Columnlist= coalesce(@Columnlist + ',','')+ c.name 
from sys.columns as c Join sys.tables as t on c.object_id=t.object_id
where t.name=@Table_name
declare @sql varchar(max)
set @sql=';With cte as (
select Row_number()over(Partition by '+@Columnlist+' order by ' +@Columnlist+ ')rno,* from '+@Table_name+')
delete from cte where rno>1'
Exec( @sql)
End  

    
     





